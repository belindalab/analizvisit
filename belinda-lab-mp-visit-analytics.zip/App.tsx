
import React, { useState, useEffect, useCallback } from 'react';
import { TabType, GlobalState, ApiResponse } from './types';
import VisitsSection from './components/VisitsSection';
import CalendarSection from './components/CalendarSection';
import AnalyticsSection from './components/AnalyticsSection';
import ReportsSection from './components/ReportsSection';
import PlanFactSection from './components/PlanFactSection';

const API_URL = "https://script.google.com/macros/s/AKfycbx15ddYHdW7Fobc-E2jnMEwxfAsqYAKY_4eLI9rGu0J4QCZWyLLK9HepM9mypgj_b7RtQ/exec";

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('visits');
  const [state, setState] = useState<GlobalState>({
    visits: [],
    employees: [],
    allEmployees: [],
    fixation: [],
    loading: true,
    error: null
  });

  const fetchData = useCallback(async () => {
    setState(prev => ({ ...prev, loading: true, error: null }));
    try {
      const response = await fetch(API_URL);
      const data: ApiResponse = await response.json();
      
      setState({
        visits: data.visits || [],
        employees: data.employees || [],
        allEmployees: data.allEmployees || data.employees || [],
        fixation: data.fixation || [],
        loading: false,
        error: null
      });
    } catch (err) {
      console.error("Fetch error:", err);
      setState(prev => ({ ...prev, loading: false, error: 'Ошибка загрузки данных. Пожалуйста, проверьте подключение.' }));
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const TabButton: React.FC<{ id: TabType; label: string }> = ({ id, label }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`px-4 py-3 text-sm font-semibold rounded-xl transition-all duration-200 whitespace-nowrap ${
        activeTab === id 
          ? 'bg-brand-accent/10 text-brand-accent shadow-sm' 
          : 'text-gray-500 hover:bg-gray-100 hover:text-brand-primary'
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="min-h-screen bg-brand-bg text-gray-900">
      <div className="max-w-[1400px] mx-auto px-4 py-6 md:px-6">
        {/* Header */}
        <header className="flex items-center justify-between gap-4 mb-6 bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <h1 className="text-lg md:text-xl font-black text-brand-primary tracking-tight">
              Система анализа визитов МП
            </h1>
            {state.loading && (
              <div className="flex items-center gap-2 text-brand-accent text-xs font-bold animate-pulse px-3 py-1 bg-brand-accent/5 rounded-full">
                <div className="w-1.5 h-1.5 rounded-full bg-brand-accent"></div>
                Загрузка...
              </div>
            )}
          </div>
          
          <img src="https://belinda.tj/img/main-logo.svg" alt="Belinda" className="h-6 md:h-8" />
        </header>

        {/* Tabs */}
        <nav className="flex items-center gap-1 overflow-x-auto custom-scrollbar mb-6 bg-white p-1.5 rounded-2xl border border-gray-200 shadow-sm">
          <TabButton id="visits" label="Визиты" />
          <TabButton id="calendar" label="Календарь визитов" />
          <TabButton id="analytics" label="Аналитика визитов" />
          <TabButton id="reports" label="Отчеты" />
          <TabButton id="planfact" label="План/Факт" />
        </nav>

        {/* Content */}
        <main className="min-h-[60vh]">
          {state.error ? (
            <div className="bg-red-50 border border-red-200 text-red-700 px-6 py-4 rounded-xl flex flex-col items-center gap-4">
              <p>{state.error}</p>
              <button onClick={fetchData} className="bg-brand-accent text-white px-6 py-2 rounded-xl font-bold hover:brightness-90">
                Попробовать снова
              </button>
            </div>
          ) : (
            <>
              {activeTab === 'visits' && <VisitsSection data={state} />}
              {activeTab === 'calendar' && <CalendarSection data={state} />}
              {activeTab === 'analytics' && <AnalyticsSection data={state} />}
              {activeTab === 'reports' && <ReportsSection data={state} />}
              {activeTab === 'planfact' && <PlanFactSection data={state} />}
            </>
          )}
        </main>

        <footer className="mt-12 text-center text-gray-400 text-xs pb-6">
          &copy; {new Date().getFullYear()} Belinda Lab. Все права защищены.
        </footer>
      </div>
    </div>
  );
};

export default App;
