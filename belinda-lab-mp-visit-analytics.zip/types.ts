
export interface Visit {
  "Дата": string;
  "Дата визита"?: string;
  "Мед представитель": string;
  "Медицинский представитель"?: string;
  "Аб ЛПУ": string;
  "ЛПУ": string;
  "Название ЛПУ"?: string;
  "Имя доктора": string;
  "Врач"?: string;
  "Специальность": string;
  "Специальность врача"?: string;
  "Территория"?: string;
}

export interface Employee {
  "МП": string;
  "Роль": string;
  "Статус": string;
  "Область": string;
  "Территория"?: string;
  "Группа": string;
}

export interface Fixation {
  "Дата": string;
  "МП": string;
  "Причина": string;
  "Причины"?: string;
}

export interface ApiResponse {
  visits: Visit[];
  employees: Employee[];
  allEmployees: Employee[];
  fixation: Fixation[];
}

export enum GroupSort {
  ALFA = 1,
  BETA = 2,
  GAMMA = 3,
  DELTA = 4,
  OTHER = 99
}

export type TabType = 'visits' | 'calendar' | 'analytics' | 'reports' | 'planfact';

export interface GlobalState {
  visits: Visit[];
  employees: Employee[];
  allEmployees: Employee[];
  fixation: Fixation[];
  loading: boolean;
  error: string | null;
}
