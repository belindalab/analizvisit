
import { GroupSort, Employee, Visit } from './types';

export const normalizeDate = (dateStr: string): string => {
  if (!dateStr) return '';
  const trimmed = dateStr.toString().trim();
  
  // Format: YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return trimmed;
  
  // Format: DD.MM.YYYY or DD/MM/YYYY
  const parts = trimmed.split(/[./-]/);
  if (parts.length === 3) {
    if (parts[0].length === 4) return `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
    return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
  }
  
  try {
    const d = new Date(trimmed);
    if (!isNaN(d.getTime())) return d.toISOString().split('T')[0];
  } catch(e) {}
  
  return trimmed;
};

export const getGroupSortValue = (group: string): number => {
  const g = group?.toLowerCase() || '';
  if (g.includes('альфа')) return GroupSort.ALFA;
  if (g.includes('бета')) return GroupSort.BETA;
  if (g.includes('гамма') || g.includes('gamma')) return GroupSort.GAMMA;
  if (g.includes('дельта') || g.includes('delta')) return GroupSort.DELTA;
  return GroupSort.OTHER;
};

export const sortEmployees = (a: Employee, b: Employee): number => {
  const groupA = getGroupSortValue(a.Группа);
  const groupB = getGroupSortValue(b.Группа);
  
  if (groupA !== groupB) return groupA - groupB;
  return a.МП.localeCompare(b.МП, 'ru');
};

export const getVisitRepName = (v: Visit): string => 
  v["Мед представитель"] || v["Медицинский представитель"] || '';

export const getVisitLPUAbbr = (v: Visit): string => 
  v["Аб ЛПУ"] || '—';

export const getVisitLPUFull = (v: Visit): string => 
  v["ЛПУ"] || v["Название ЛПУ"] || '—';

export const getVisitDoctor = (v: Visit): string => 
  v["Имя доктора"] || v["Врач"] || '—';

export const getVisitSpec = (v: Visit): string => 
  v["Специальность"] || v["Специальность врача"] || '—';

export const getVisitDate = (v: Visit): string => 
  v["Дата"] || v["Дата визита"] || '';

export const isSameDay = (d1: Date, d2: Date) => 
  d1.getFullYear() === d2.getFullYear() &&
  d1.getMonth() === d2.getMonth() &&
  d1.getDate() === d2.getDate();
