
import React, { useState, useMemo } from 'react';
import { GlobalState, Employee } from '../types';
import { normalizeDate, sortEmployees, getVisitRepName } from '../utils';

interface Props {
  data: GlobalState;
}

const PlanFactSection: React.FC<Props> = ({ data }) => {
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [selectedTerr, setSelectedTerr] = useState('');
  const [selectedRep, setSelectedRep] = useState('');
  const [selectedRole, setSelectedRole] = useState('МП');
  const [selectedStatus, setSelectedStatus] = useState('');

  const [year, month] = selectedMonth.split('-').map(Number);
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0);

  const territories = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Область))).sort(), [data.allEmployees]);
  const repsList = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.МП))).sort(), [data.allEmployees]);
  const roles = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Роль))).sort(), [data.allEmployees]);
  const statuses = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Статус))).sort(), [data.allEmployees]);

  const monthVisits = useMemo(() => {
    return data.visits.filter(v => {
      const d = new Date(normalizeDate(v.Дата || v["Дата визита"] || ''));
      return !isNaN(d.getTime()) && d >= startDate && d <= endDate;
    });
  }, [data.visits, startDate, endDate]);

  const groupedData = useMemo(() => {
    const filtered = data.allEmployees.filter(emp => {
      if (selectedTerr && emp.Область !== selectedTerr) return false;
      if (selectedRep && emp.МП !== selectedRep) return false;
      if (selectedRole && emp.Роль !== selectedRole) return false;
      if (selectedStatus && emp.Статус !== selectedStatus) return false;
      return true;
    }).sort(sortEmployees);

    const grouped: Record<string, Employee[]> = {};
    filtered.forEach(emp => {
      if (!grouped[emp.Область]) grouped[emp.Область] = [];
      grouped[emp.Область].push(emp);
    });
    return grouped;
  }, [data.allEmployees, selectedTerr, selectedRep, selectedRole, selectedStatus]);

  const PLAN_MONTH = 288;
  const PLAN_DAY = 12;

  const stats = useMemo(() => {
    const results: Record<string, any> = {};
    Object.values(groupedData).flat().forEach(emp => {
      const repVisits = monthVisits.filter(v => getVisitRepName(v) === emp.МП);
      const daysWithVisits = new Set(repVisits.map(v => normalizeDate(v.Дата || v["Дата визита"] || ''))).size;
      
      const fact = repVisits.length;
      const deviation = fact - PLAN_MONTH;
      const percentage = Math.round((fact / PLAN_MONTH) * 100);
      const avg = daysWithVisits > 0 ? (fact / daysWithVisits).toFixed(1) : 0;

      results[emp.МП] = { fact, deviation, percentage, avg, days: daysWithVisits };
    });
    return results;
  }, [groupedData, monthVisits]);

  return (
    <div className="space-y-6">
      <div className="bg-brand-primary text-white p-6 rounded-2xl shadow-sm flex items-center justify-between border border-brand-primary/20">
        <div>
          <h2 className="text-xl font-bold mb-1">Целевые показатели</h2>
          <p className="text-xs text-gray-300">План на месяц: <span className="text-white font-bold">{PLAN_MONTH} визитов</span></p>
          <p className="text-xs text-gray-300">План в день: <span className="text-white font-bold">~{PLAN_DAY} визитов</span></p>
        </div>
        <div className="text-right hidden sm:block">
          <div className="text-[40px] font-black opacity-20">288</div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Месяц</label>
          <input type="month" value={selectedMonth} onChange={e => setSelectedMonth(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none" />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Территория</label>
          <select value={selectedTerr} onChange={e => setSelectedTerr(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {territories.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">МП</label>
          <select value={selectedRep} onChange={e => setSelectedRep(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {repsList.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Роль</label>
          <select value={selectedRole} onChange={e => setSelectedRole(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {roles.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Статус</label>
          <select value={selectedStatus} onChange={e => setSelectedStatus(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {statuses.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm border-collapse">
            <thead className="bg-gray-100 text-gray-500 text-[10px] uppercase font-bold text-left">
              <tr>
                <th className="px-4 py-3">Мед Представитель</th>
                <th className="px-4 py-3">Группа</th>
                <th className="px-4 py-3 text-right">План</th>
                <th className="px-4 py-3 text-right">Факт</th>
                <th className="px-4 py-3 text-right">Отклонение</th>
                <th className="px-4 py-3 text-right">% выполнения</th>
                <th className="px-4 py-3 text-right">Ср/день</th>
                <th className="px-4 py-3 text-right">Дней</th>
              </tr>
            </thead>
            <tbody>
              {Object.keys(groupedData).sort().map(terr => (
                <React.Fragment key={terr}>
                  <tr className="bg-gray-100 font-bold text-brand-primary border-y border-gray-200">
                    <td colSpan={8} className="px-4 py-2">{terr}</td>
                  </tr>
                  {groupedData[terr].map(emp => {
                    const s = stats[emp.МП] || { fact: 0, deviation: -PLAN_MONTH, percentage: 0, avg: 0, days: 0 };
                    const pctColor = s.percentage >= 100 ? 'text-green-600' : s.percentage >= 80 ? 'text-orange-500' : 'text-brand-accent';
                    const devColor = s.deviation >= 0 ? 'text-green-600' : 'text-brand-accent';
                    const avgColor = Number(s.avg) >= PLAN_DAY ? 'text-green-600' : Number(s.avg) >= (PLAN_DAY * 0.8) ? 'text-orange-500' : 'text-brand-accent';

                    return (
                      <tr key={emp.МП} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                        <td className="px-4 py-3 font-semibold text-brand-primary">{emp.МП}</td>
                        <td className="px-4 py-3 text-gray-400">{emp.Группа}</td>
                        <td className="px-4 py-3 text-right font-medium">288</td>
                        <td className="px-4 py-3 text-right font-bold">{s.fact}</td>
                        <td className={`px-4 py-3 text-right font-bold ${devColor}`}>
                          {s.deviation > 0 ? `+${s.deviation}` : s.deviation}
                        </td>
                        <td className={`px-4 py-3 text-right font-black ${pctColor}`}>{s.percentage}%</td>
                        <td className={`px-4 py-3 text-right font-bold ${avgColor}`}>{s.avg}</td>
                        <td className="px-4 py-3 text-right text-gray-500">{s.days}</td>
                      </tr>
                    );
                  })}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PlanFactSection;
