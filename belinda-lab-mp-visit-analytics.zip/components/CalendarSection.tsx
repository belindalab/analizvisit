
import React, { useState, useMemo } from 'react';
import { GlobalState, Employee, Visit } from '../types';
import { normalizeDate, sortEmployees, getVisitRepName, getVisitDoctor, getVisitSpec, getVisitLPUAbbr, getVisitLPUFull } from '../utils';

interface Props {
  data: GlobalState;
}

const CalendarSection: React.FC<Props> = ({ data }) => {
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [selectedTerr, setSelectedTerr] = useState('');
  const [selectedRep, setSelectedRep] = useState('');
  const [selectedRole, setSelectedRole] = useState('МП');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [selectedAbsenceFilter, setSelectedAbsenceFilter] = useState('');
  
  const [showWeekendSelector, setShowWeekendSelector] = useState(false);
  const [manualWeekends, setManualWeekends] = useState<Set<string>>(new Set());
  
  const [modalData, setModalData] = useState<{ repName: string, date: string, visits: Visit[] } | null>(null);
  const [reasonModal, setReasonModal] = useState<{ repName: string, date: string, reason: string } | null>(null);

  const year = parseInt(selectedMonth.split('-')[0]);
  const month = parseInt(selectedMonth.split('-')[1]) - 1;

  const monthDays = useMemo(() => {
    const days: Date[] = [];
    const date = new Date(year, month, 1);
    while (date.getMonth() === month) {
      days.push(new Date(date));
      date.setDate(date.getDate() + 1);
    }
    return days;
  }, [year, month]);

  const autoWeekends = useMemo(() => {
    const set = new Set<string>();
    monthDays.forEach(d => {
      const dayOfWeek = d.getDay();
      const weekNum = Math.ceil(d.getDate() / 7);
      if (dayOfWeek === 0 || (dayOfWeek === 6 && weekNum % 2 === 0)) {
        set.add(d.toISOString().split('T')[0]);
      }
    });
    return set;
  }, [monthDays]);

  const effectiveWeekends = useMemo(() => {
    return manualWeekends.size > 0 ? manualWeekends : autoWeekends;
  }, [manualWeekends, autoWeekends]);

  const workingDays = monthDays.filter(d => !effectiveWeekends.has(d.toISOString().split('T')[0]));

  const absenceReasonsList = useMemo(() => {
    const set = new Set<string>();
    data.fixation.forEach(f => {
      const r = f.Причина || f.Причины;
      if (r) set.add(r);
    });
    return Array.from(set).sort();
  }, [data.fixation]);

  const getDayVisitsList = (repName: string, date: Date): Visit[] => {
    const dateStr = date.toISOString().split('T')[0];
    return data.visits.filter(v => {
      const vDate = normalizeDate(v.Дата || v["Дата визита"] || '');
      return vDate === dateStr && getVisitRepName(v) === repName;
    });
  };

  const getAbsenceReason = (repName: string, date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    const fix = data.fixation.find(f => normalizeDate(f.Дата) === dateStr && f.МП === repName);
    return fix ? (fix.Причина || fix.Причины || '') : null;
  };

  const groupedData = useMemo(() => {
    const filtered = data.allEmployees.filter(emp => {
      if (selectedTerr && emp.Область !== selectedTerr) return false;
      if (selectedRep && emp.МП !== selectedRep) return false;
      if (selectedRole && emp.Роль !== selectedRole) return false;
      if (selectedStatus && emp.Статус !== selectedStatus) return false;
      
      if (selectedAbsenceFilter) {
        const hasReasonInMonth = monthDays.some(d => getAbsenceReason(emp.МП, d) === selectedAbsenceFilter);
        if (!hasReasonInMonth) return false;
      }
      
      return true;
    }).sort(sortEmployees);

    const grouped: Record<string, Employee[]> = {};
    filtered.forEach(emp => {
      if (!grouped[emp.Область]) grouped[emp.Область] = [];
      grouped[emp.Область].push(emp);
    });
    return grouped;
  }, [data.allEmployees, selectedTerr, selectedRep, selectedRole, selectedStatus, selectedAbsenceFilter, monthDays, data.fixation]);

  const getReasonColorClass = (reason: string | null) => {
    if (!reason) return '';
    const r = reason.toLowerCase();
    if (r.includes('больнич')) return 'bg-red-50 text-red-700';
    if (r.includes('отпуск')) return 'bg-blue-50 text-blue-700';
    if (r.includes('отпросил')) return 'bg-orange-50 text-orange-700';
    if (r.includes('не заполнил')) return 'bg-yellow-50 text-yellow-700';
    if (r.includes('нет crm')) return 'bg-gray-100 text-gray-700';
    return 'bg-gray-50 text-gray-600';
  };

  const handleCellClick = (repName: string, date: Date) => {
    const visits = getDayVisitsList(repName, date);
    const reason = getAbsenceReason(repName, date);
    
    if (visits.length > 0) {
      setModalData({
        repName,
        date: date.toLocaleDateString('ru-RU'),
        visits
      });
    } else if (reason) {
      setReasonModal({
        repName,
        date: date.toLocaleDateString('ru-RU'),
        reason
      });
    }
  };

  const territories = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Область))).sort(), [data.allEmployees]);
  const repsList = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.МП))).sort(), [data.allEmployees]);
  const roles = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Роль))).sort(), [data.allEmployees]);
  const statuses = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Статус))).sort(), [data.allEmployees]);

  const InfoIcon = ({ className }: { className?: string }) => (
    <svg className={className} width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M12 16V12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M12 8H12.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );

  return (
    <div className="space-y-6">
      {/* Filters Bar */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 bg-white p-4 rounded-2xl border border-gray-200 shadow-sm items-end">
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Месяц</label>
          <input type="month" value={selectedMonth} onChange={e => setSelectedMonth(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none" />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Территория</label>
          <select value={selectedTerr} onChange={e => setSelectedTerr(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {territories.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">МП</label>
          <select value={selectedRep} onChange={e => setSelectedRep(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {repsList.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Роль</label>
          <select value={selectedRole} onChange={e => setSelectedRole(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {roles.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Статус</label>
          <select value={selectedStatus} onChange={e => setSelectedStatus(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {statuses.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Причина (фильтр)</label>
          <select value={selectedAbsenceFilter} onChange={e => setSelectedAbsenceFilter(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {absenceReasonsList.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
      </div>

      {showWeekendSelector && (
        <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm animate-fadeIn">
          <div className="text-sm font-bold text-brand-primary mb-3">Выберите выходные:</div>
          <div className="grid grid-cols-7 gap-2">
            {monthDays.map(d => {
              const dStr = d.toISOString().split('T')[0];
              const isWk = effectiveWeekends.has(dStr);
              return (
                <button
                  key={dStr}
                  onClick={() => {
                    const next = new Set(effectiveWeekends);
                    if (next.has(dStr)) next.delete(dStr);
                    else next.add(dStr);
                    setManualWeekends(next);
                  }}
                  className={`p-2 rounded-lg text-xs font-bold transition-all ${isWk ? 'bg-red-100 text-red-600 border border-red-200' : 'bg-gray-50 text-gray-600 border border-gray-100 hover:bg-gray-100'}`}
                >
                  {d.getDate()}
                </button>
              );
            })}
          </div>
          <div className="mt-4 flex justify-end gap-2">
            <button onClick={() => setManualWeekends(new Set())} className="text-xs text-gray-400 font-bold hover:text-brand-accent">Сбросить</button>
            <button onClick={() => setShowWeekendSelector(false)} className="bg-brand-accent text-white px-4 py-1 rounded-lg text-xs font-bold">Готово</button>
          </div>
        </div>
      )}

      {/* Stretched Day Statistics Block with Weekends Action */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex-1 w-full">
          <h3 className="text-sm font-bold text-brand-primary mb-4 border-b border-gray-100 pb-2">Статистика дней</h3>
          <div className="flex gap-12">
            <div>
              <div className="text-[11px] text-gray-400 font-bold uppercase tracking-wider">Рабочих дней</div>
              <div className="text-3xl font-black text-brand-accent">{workingDays.length}</div>
            </div>
            <div>
              <div className="text-[11px] text-gray-400 font-bold uppercase tracking-wider">Выходных дней</div>
              <div className="text-3xl font-black text-gray-500">{effectiveWeekends.size}</div>
            </div>
          </div>
          <p className="text-[11px] text-gray-400 mt-4 italic font-medium leading-relaxed">
            * Дни с причинами отсутствия автоматически исключаются из расчета % выполнения плана.
          </p>
        </div>
        
        <div className="flex flex-col gap-3 w-full md:w-auto">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider text-center md:text-left">Настройка календаря</label>
          <button 
            onClick={() => setShowWeekendSelector(!showWeekendSelector)} 
            className={`flex items-center justify-center gap-2 px-8 py-3 rounded-xl text-sm font-bold transition-all shadow-sm h-[48px] ${
              showWeekendSelector 
                ? 'bg-brand-accent text-white shadow-brand-accent/20' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
              <line x1="16" y1="2" x2="16" y2="6"></line>
              <line x1="8" y1="2" x2="8" y2="6"></line>
              <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
            Управление выходными
          </button>
        </div>
      </div>

      {/* Calendar Table */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-[11px] border-collapse min-w-[1200px]">
            <thead className="bg-brand-primary text-white font-bold sticky top-0 z-20">
              <tr>
                <th className="px-3 py-2 text-left sticky left-0 bg-brand-primary z-30 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.3)] w-48">МП</th>
                {monthDays.map(d => {
                  const dStr = d.toISOString().split('T')[0];
                  const isWk = effectiveWeekends.has(dStr);
                  const isToday = isSameDay(d, new Date());
                  return (
                    <th key={dStr} className={`px-1 py-2 text-center border-l border-white/10 ${isWk ? 'bg-red-600/50' : isToday ? 'bg-brand-accent shadow-inner' : ''}`}>
                      {d.getDate()}<br/>
                      <span className="text-[9px] opacity-70">
                        {['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'][d.getDay()]}
                      </span>
                    </th>
                  );
                })}
                <th className="px-2 py-2 border-l border-white/20 bg-brand-primary/90">Зап</th>
                <th className="px-2 py-2 bg-brand-primary/90">Пуст</th>
                <th className="px-2 py-2 bg-brand-primary/90 text-brand-accent" title="С учетом исключенных причин">%</th>
                <th className="px-2 py-2 bg-brand-primary/90">Итого</th>
              </tr>
            </thead>
            <tbody>
              {Object.keys(groupedData).sort().map(terr => (
                <React.Fragment key={terr}>
                  <tr className="bg-gray-100 font-bold text-brand-primary border-y border-gray-200">
                    <td colSpan={monthDays.length + 5} className="px-4 py-1.5 sticky left-0 z-10">{terr}</td>
                  </tr>
                  {groupedData[terr].map(emp => {
                    let filled = 0;
                    let empty = 0;
                    let totalVisitsCount = 0;
                    let excludedDaysCount = 0;

                    const dayCells = monthDays.map(d => {
                      const dStr = d.toISOString().split('T')[0];
                      const isWk = effectiveWeekends.has(dStr);
                      const dayVisits = getDayVisitsList(emp.МП, d);
                      const visitsCount = dayVisits.length;
                      const reason = getAbsenceReason(emp.МП, d);
                      
                      if (!isWk) {
                        if (visitsCount > 0) {
                          filled++;
                          totalVisitsCount += visitsCount;
                        } else {
                          empty++;
                        }
                        if (reason) {
                          excludedDaysCount++;
                        }
                      }

                      return (
                        <td 
                          key={dStr} 
                          onClick={() => handleCellClick(emp.МП, d)}
                          className={`p-1 text-center border-l border-gray-100 relative transition-colors ${isWk ? 'bg-red-50' : getReasonColorClass(reason)} ${ (visitsCount > 0 || reason) ? 'cursor-pointer hover:bg-brand-accent/5' : ''}`}
                        >
                          <div className="flex flex-col items-center justify-center min-h-[24px]">
                            {visitsCount > 0 ? (
                              <span className="font-bold text-brand-accent">{visitsCount}</span>
                            ) : !reason && (
                              <span className="text-gray-300">·</span>
                            )}
                            
                            {reason && (
                              <div className={`${visitsCount > 0 ? 'absolute top-0 right-0 p-0.5' : 'flex items-center justify-center'}`}>
                                <InfoIcon className="text-brand-primary hover:text-brand-accent transition-colors opacity-80" />
                              </div>
                            )}
                          </div>
                        </td>
                      );
                    });

                    const workingDaysTotal = workingDays.length;
                    const effectiveDenominator = workingDaysTotal - excludedDaysCount;
                    const percentage = effectiveDenominator > 0 ? Math.round((filled / effectiveDenominator) * 100) : 0;

                    return (
                      <tr key={emp.МП} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                        <td className="px-3 py-2 font-semibold text-brand-primary sticky left-0 bg-white z-10 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.1)]">
                          {emp.МП}
                        </td>
                        {dayCells}
                        <td className="px-2 py-2 text-center bg-gray-50 border-l border-gray-100 font-bold">{filled}</td>
                        <td className="px-2 py-2 text-center bg-gray-50 text-gray-400">{empty}</td>
                        <td className="px-2 py-2 text-center bg-gray-50 font-bold text-brand-accent">{percentage}%</td>
                        <td className="px-2 py-2 text-center bg-brand-primary/5 font-bold text-brand-primary">{totalVisitsCount}</td>
                      </tr>
                    );
                  })}
                </React.Fragment>
              ))}
              {Object.keys(groupedData).length === 0 && (
                <tr>
                  <td colSpan={monthDays.length + 5} className="px-4 py-12 text-center text-gray-400 italic">
                    Нет сотрудников для отображения
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Visits Detail Modal */}
      {modalData && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm transition-opacity animate-fadeIn">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh] animate-slideIn">
            <div className="bg-brand-primary p-4 text-white flex justify-between items-center">
              <div>
                <h3 className="font-bold text-lg">{modalData.repName}</h3>
                <p className="text-xs text-gray-300">{modalData.date} • {modalData.visits.length} визитов</p>
              </div>
              <button onClick={() => setModalData(null)} className="w-8 h-8 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 text-white">✕</button>
            </div>
            <div className="p-4 overflow-y-auto custom-scrollbar bg-gray-50 flex-1">
              <div className="grid gap-3">
                {modalData.visits.map((v, i) => (
                  <div key={i} className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
                    <div className="flex justify-between items-start mb-1">
                      <div className="font-bold text-brand-primary text-sm">{getVisitDoctor(v)}</div>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-brand-accent/10 text-brand-accent font-bold uppercase">{getVisitSpec(v)}</span>
                    </div>
                    <div className="text-xs text-gray-500 font-medium">{getVisitLPUAbbr(v)}: {getVisitLPUFull(v)}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="p-4 bg-white border-t border-gray-100 flex justify-end">
              <button onClick={() => setModalData(null)} className="px-6 py-2 bg-gray-100 text-gray-600 rounded-xl font-bold text-sm hover:bg-gray-200">Закрыть</button>
            </div>
          </div>
        </div>
      )}

      {/* Absence Reason Modal */}
      {reasonModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animate-slideIn">
            <div className="bg-brand-primary p-4 text-white flex justify-between items-center">
              <div>
                <h3 className="font-bold text-lg">Причина отсутствия</h3>
                <p className="text-xs text-gray-300">{reasonModal.repName} • {reasonModal.date}</p>
              </div>
              <button onClick={() => setReasonModal(null)} className="text-white font-bold">✕</button>
            </div>
            <div className="p-8 text-center">
              <div className="w-16 h-16 bg-brand-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <InfoIcon className="text-brand-accent w-10 h-10" />
              </div>
              <div className="text-xl font-bold text-brand-primary mb-2">
                {reasonModal.reason}
              </div>
              <p className="text-sm text-gray-500">Запись о фиксации отсутствия на выбранную дату.</p>
            </div>
            <div className="p-4 bg-gray-50 flex justify-end">
              <button onClick={() => setReasonModal(null)} className="px-8 py-2 bg-brand-primary text-white rounded-xl font-bold text-sm shadow-md hover:brightness-110">Понятно</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const isSameDay = (d1: Date, d2: Date) => 
  d1.getFullYear() === d2.getFullYear() &&
  d1.getMonth() === d2.getMonth() &&
  d1.getDate() === d2.getDate();

export default CalendarSection;
