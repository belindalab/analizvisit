
import React, { useState, useMemo } from 'react';
import { GlobalState, Visit } from '../types';
import { normalizeDate, getVisitLPUAbbr, getVisitLPUFull, getVisitDoctor, getVisitSpec, getVisitRepName, getVisitDate } from '../utils';
import { DetailModal } from './AnalyticsSection';

interface Props {
  data: GlobalState;
}

const ReportsSection: React.FC<Props> = ({ data }) => {
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [selectedTerr, setSelectedTerr] = useState('');
  const [selectedRep, setSelectedRep] = useState('');
  const [selectedRole, setSelectedRole] = useState('МП');
  const [selectedStatus, setSelectedStatus] = useState('');

  const [modalInfo, setModalInfo] = useState<{ title: string; subtitle: string; items: Visit[] } | null>(null);

  const [year, month] = selectedMonth.split('-').map(Number);
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0);

  const territories = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Область))).sort(), [data.allEmployees]);
  const repsList = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.МП))).sort(), [data.allEmployees]);
  const roles = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Роль))).sort(), [data.allEmployees]);
  const statuses = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Статус))).sort(), [data.allEmployees]);

  const monthVisits = useMemo(() => {
    return data.visits.filter(v => {
      const dStr = normalizeDate(getVisitDate(v));
      const d = new Date(dStr);
      if (isNaN(d.getTime())) return false;
      
      const repName = getVisitRepName(v);
      const emp = data.allEmployees.find(e => e.МП === repName);
      
      if (selectedRep && repName !== selectedRep) return false;
      if (selectedTerr && emp?.Область !== selectedTerr) return false;
      if (selectedRole && emp?.Роль !== selectedRole) return false;
      if (selectedStatus && emp?.Статус !== selectedStatus) return false;

      return d >= startDate && d <= endDate;
    });
  }, [data.visits, data.allEmployees, startDate, endDate, selectedRep, selectedTerr, selectedRole, selectedStatus]);

  const lpuReport = useMemo(() => {
    const lpus: Record<string, any> = {};
    monthVisits.forEach(v => {
      const abbr = getVisitLPUAbbr(v);
      const full = getVisitLPUFull(v);
      const key = `${abbr} - ${full}`;
      if (!lpus[key]) {
        lpus[key] = { abbr, full, visits: 0, reps: new Set(), docs: new Set(), allVisits: [] };
      }
      lpus[key].visits++;
      lpus[key].reps.add(getVisitRepName(v));
      lpus[key].docs.add(getVisitDoctor(v));
      lpus[key].allVisits.push(v);
    });
    return Object.values(lpus).sort((a, b) => b.visits - a.visits);
  }, [monthVisits]);

  const specReport = useMemo(() => {
    const specs: Record<string, any> = {};
    monthVisits.forEach(v => {
      const spec = getVisitSpec(v);
      if (!specs[spec]) {
        specs[spec] = { name: spec, visits: 0, docs: new Set(), lpus: new Set(), reps: new Set(), allVisits: [] };
      }
      specs[spec].visits++;
      specs[spec].docs.add(getVisitDoctor(v));
      specs[spec].lpus.add(getVisitLPUAbbr(v));
      specs[spec].reps.add(getVisitRepName(v));
      specs[spec].allVisits.push(v);
    });
    return Object.values(specs).sort((a, b) => b.visits - a.visits);
  }, [monthVisits]);

  const handleLpuClick = (lpu: any) => {
    setModalInfo({
      title: lpu.abbr,
      subtitle: `${lpu.full} • ${lpu.visits} визитов`,
      items: lpu.allVisits
    });
  };

  const handleSpecClick = (spec: any) => {
    setModalInfo({
      title: spec.name,
      subtitle: `${spec.visits} визитов к специалисту`,
      items: spec.allVisits
    });
  };

  return (
    <div className="space-y-8">
      {/* Filters */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Месяц</label>
          <input type="month" value={selectedMonth} onChange={e => setSelectedMonth(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none" />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Территория</label>
          <select value={selectedTerr} onChange={e => setSelectedTerr(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {territories.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">МП</label>
          <select value={selectedRep} onChange={e => setSelectedRep(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {repsList.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Роль</label>
          <select value={selectedRole} onChange={e => setSelectedRole(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {roles.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Статус</label>
          <select value={selectedStatus} onChange={e => setSelectedStatus(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {statuses.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* LPU Table */}
        <section>
          <h2 className="text-base font-bold text-brand-primary mb-4 flex items-center gap-2 border-b-2 border-brand-accent pb-1 w-fit">
            Охват МП по АБ ЛПУ
          </h2>
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead className="bg-gray-100 text-gray-500 text-[10px] uppercase font-bold text-left">
                  <tr>
                    <th className="px-3 py-2">АБ ЛПУ</th>
                    <th className="px-3 py-2">ЛПУ</th>
                    <th className="px-3 py-2 text-right">Визитов</th>
                    <th className="px-3 py-2 text-right">МП</th>
                    <th className="px-3 py-2 text-right">Врачи</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {lpuReport.map((l, i) => (
                    <tr 
                      key={i} 
                      className="hover:bg-gray-50 transition-colors cursor-pointer group"
                      onClick={() => handleLpuClick(l)}
                    >
                      <td className="px-3 py-2 font-bold text-brand-primary">{l.abbr}</td>
                      <td className="px-3 py-2 text-xs text-gray-600 line-clamp-1">{l.full}</td>
                      <td className="px-3 py-2 text-right font-bold text-brand-accent group-hover:underline decoration-dotted">{l.visits}</td>
                      <td className="px-3 py-2 text-right font-medium text-gray-500">{l.reps.size}</td>
                      <td className="px-3 py-2 text-right font-medium text-gray-500">{l.docs.size}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* Specialists Table */}
        <section>
          <h2 className="text-base font-bold text-brand-primary mb-4 flex items-center gap-2 border-b-2 border-brand-accent pb-1 w-fit">
            Часто посещаемые специалисты
          </h2>
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead className="bg-gray-100 text-gray-500 text-[10px] uppercase font-bold text-left">
                  <tr>
                    <th className="px-3 py-2">Специальность</th>
                    <th className="px-3 py-2 text-right">Визитов</th>
                    <th className="px-3 py-2 text-right">Врачи</th>
                    <th className="px-3 py-2 text-right">ЛПУ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {specReport.map((s, i) => (
                    <tr 
                      key={i} 
                      className="hover:bg-gray-50 transition-colors cursor-pointer group"
                      onClick={() => handleSpecClick(s)}
                    >
                      <td className="px-3 py-2 font-bold text-brand-primary">{s.name}</td>
                      <td className="px-3 py-2 text-right font-bold text-brand-accent group-hover:underline decoration-dotted">{s.visits}</td>
                      <td className="px-3 py-2 text-right font-medium text-gray-500">{s.docs.size}</td>
                      <td className="px-3 py-2 text-right font-medium text-gray-500">{s.lpus.size}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>

      {modalInfo && (
        <DetailModal 
          title={modalInfo.title}
          subtitle={modalInfo.subtitle}
          items={modalInfo.items}
          onClose={() => setModalInfo(null)}
        />
      )}
    </div>
  );
};

export default ReportsSection;
