
import React, { useState, useMemo } from 'react';
import { GlobalState, Visit, Employee } from '../types';
import { normalizeDate, sortEmployees, getVisitRepName, getVisitDoctor, getVisitSpec, getVisitLPUAbbr, getVisitLPUFull, getVisitDate } from '../utils';

interface Props {
  data: GlobalState;
}

interface DetailModalProps {
  title: string;
  subtitle: string;
  items: Visit[];
  onClose: () => void;
}

export const DetailModal: React.FC<DetailModalProps> = ({ title, subtitle, items, onClose }) => {
  const groupedItems = useMemo(() => {
    const groups: Record<string, { 
      doctor: string, 
      spec: string, 
      lpuAbbr: string, 
      lpuFull: string, 
      dates: string[] 
    }> = {};

    items.forEach(v => {
      const doc = getVisitDoctor(v);
      const lpu = getVisitLPUAbbr(v);
      const key = `${doc}-${lpu}`;
      
      if (!groups[key]) {
        groups[key] = {
          doctor: doc,
          spec: getVisitSpec(v),
          lpuAbbr: lpu,
          lpuFull: getVisitLPUFull(v),
          dates: []
        };
      }
      const dateStr = normalizeDate(getVisitDate(v));
      if (dateStr && !groups[key].dates.includes(dateStr)) {
        groups[key].dates.push(dateStr);
      }
    });

    return Object.values(groups).sort((a, b) => a.doctor.localeCompare(b.doctor, 'ru'));
  }, [items]);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-slideIn">
        <div className="bg-brand-primary p-4 text-white flex justify-between items-center">
          <div>
            <h3 className="font-bold text-lg">{title}</h3>
            <p className="text-xs text-gray-300">{subtitle}</p>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 transition-colors text-white font-bold"
          >
            ✕
          </button>
        </div>
        <div className="p-4 overflow-y-auto custom-scrollbar bg-gray-50 flex-1">
          <div className="grid gap-3">
            {groupedItems.length > 0 ? (
              groupedItems.map((group, i) => (
                <div key={i} className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex flex-col gap-1">
                  <div className="flex justify-between items-start">
                    <div className="font-bold text-brand-primary text-sm">{group.doctor}</div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-brand-accent/10 text-brand-accent font-bold uppercase">
                      {group.spec}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500 font-medium">
                    {group.lpuAbbr}: <span className="text-gray-700">{group.lpuFull}</span>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    <span className="text-[10px] text-gray-400 font-bold uppercase mr-1">Даты визитов:</span>
                    {group.dates.sort().map((date, idx) => (
                      <span key={idx} className="bg-gray-100 px-2 py-0.5 rounded-md text-[10px] text-gray-600 font-medium border border-gray-200">
                        {date}
                      </span>
                    ))}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-10 text-gray-400 italic">Нет данных для отображения</div>
            )}
          </div>
        </div>
        <div className="p-4 bg-white border-t border-gray-100 flex justify-end">
          <button 
            onClick={onClose}
            className="px-6 py-2 bg-brand-primary text-white rounded-xl font-bold text-sm hover:brightness-110 transition-colors shadow-md"
          >
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
};

const AnalyticsSection: React.FC<Props> = ({ data }) => {
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [selectedTerr, setSelectedTerr] = useState('');
  const [selectedRep, setSelectedRep] = useState('');
  const [selectedRole, setSelectedRole] = useState('МП');
  const [selectedStatus, setSelectedStatus] = useState('');

  const [modalInfo, setModalInfo] = useState<{ title: string; subtitle: string; items: Visit[] } | null>(null);

  const [year, month] = selectedMonth.split('-').map(Number);
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0);

  const prevPeriodStart = new Date(year, month - 4, 1);
  const prevPeriodEnd = new Date(year, month - 1, 0);

  const territories = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Область))).sort(), [data.allEmployees]);
  const repsList = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.МП))).sort(), [data.allEmployees]);
  const roles = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Роль))).sort(), [data.allEmployees]);
  const statuses = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Статус))).sort(), [data.allEmployees]);

  const monthVisits = useMemo(() => {
    return data.visits.filter(v => {
      const d = new Date(normalizeDate(getVisitDate(v)));
      return !isNaN(d.getTime()) && d >= startDate && d <= endDate;
    });
  }, [data.visits, startDate, endDate]);

  const prevPeriodVisits = useMemo(() => {
    return data.visits.filter(v => {
      const d = new Date(normalizeDate(getVisitDate(v)));
      return !isNaN(d.getTime()) && d >= prevPeriodStart && d <= prevPeriodEnd;
    });
  }, [data.visits, prevPeriodStart, prevPeriodEnd]);

  const groupedData = useMemo(() => {
    const filtered = data.allEmployees.filter(emp => {
      if (selectedTerr && emp.Область !== selectedTerr) return false;
      if (selectedRep && emp.МП !== selectedRep) return false;
      if (selectedRole && emp.Роль !== selectedRole) return false;
      if (selectedStatus && emp.Статус !== selectedStatus) return false;
      return true;
    }).sort(sortEmployees);

    const grouped: Record<string, Employee[]> = {};
    filtered.forEach(emp => {
      if (!grouped[emp.Область]) grouped[emp.Область] = [];
      grouped[emp.Область].push(emp);
    });
    return grouped;
  }, [data.allEmployees, selectedTerr, selectedRep, selectedRole, selectedStatus]);

  const stats = useMemo(() => {
    const results: Record<string, any> = {};
    
    Object.values(groupedData).flat().forEach(emp => {
      const repVisits = monthVisits.filter(v => getVisitRepName(v) === emp.МП);
      const prevVisits = prevPeriodVisits.filter(v => getVisitRepName(v) === emp.МП);
      
      const daysWithVisits = new Set(repVisits.map(v => normalizeDate(getVisitDate(v)))).size;
      const docToVisits: Record<string, Visit[]> = {};
      repVisits.forEach(v => {
        const doc = getVisitDoctor(v);
        if (!docToVisits[doc]) docToVisits[doc] = [];
        docToVisits[doc].push(v);
      });

      const distribution: Record<string, Visit[]> = { '1': [], '2': [], '3': [], '4': [], '5+': [] };
      Object.entries(docToVisits).forEach(([doc, visits]) => {
        const count = visits.length;
        if (count === 1) distribution['1'].push(...visits);
        else if (count === 2) distribution['2'].push(...visits);
        else if (count === 3) distribution['3'].push(...visits);
        else if (count === 4) distribution['4'].push(...visits);
        else if (count >= 5) distribution['5+'].push(...visits);
      });

      const prevDocs = new Set(prevVisits.map(v => getVisitDoctor(v)));
      const newDocsVisits = repVisits.filter(v => !prevDocs.has(getVisitDoctor(v)));
      const newDocsUniqueCount = new Set(newDocsVisits.map(v => getVisitDoctor(v))).size;

      results[emp.МП] = {
        avg: daysWithVisits > 0 ? Math.round(repVisits.length / daysWithVisits) : 0,
        total: repVisits.length,
        allVisits: repVisits,
        dist: distribution,
        newDocsCount: newDocsUniqueCount,
        newDocsVisits: newDocsVisits
      };
    });

    return results;
  }, [groupedData, monthVisits, prevPeriodVisits]);

  const handleCellClick = (repName: string, type: string, visits: Visit[]) => {
    if (!visits || visits.length === 0) return;
    
    let title = "";
    switch(type) {
      case 'total': title = "Все визиты"; break;
      case 'new': title = "Новые врачи"; break;
      default: title = `Врачи с кратностью ${type}`;
    }

    setModalInfo({
      title,
      subtitle: `${repName} • ${visits.length} записей`,
      items: visits
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Месяц</label>
          <input type="month" value={selectedMonth} onChange={e => setSelectedMonth(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none" />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Территория</label>
          <select value={selectedTerr} onChange={e => setSelectedTerr(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {territories.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">МП</label>
          <select value={selectedRep} onChange={e => setSelectedRep(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {repsList.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Роль</label>
          <select value={selectedRole} onChange={e => setSelectedRole(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {roles.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Статус</label>
          <select value={selectedStatus} onChange={e => setSelectedStatus(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {statuses.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm border-collapse">
            <thead className="bg-brand-primary text-white text-xs uppercase font-bold text-left">
              <tr>
                <th className="px-4 py-3">Мед Представитель</th>
                <th className="px-4 py-3">Группа</th>
                <th className="px-4 py-3 text-right">Ср/день</th>
                <th className="px-4 py-3 text-right">Всего</th>
                <th className="px-3 py-3 text-center border-l border-white/10">1</th>
                <th className="px-3 py-3 text-center">2</th>
                <th className="px-3 py-3 text-center">3</th>
                <th className="px-3 py-3 text-center">4</th>
                <th className="px-3 py-3 text-center">5+</th>
                <th className="px-4 py-3 text-right text-white">Новых</th>
              </tr>
            </thead>
            <tbody>
              {Object.keys(groupedData).sort().map(terr => (
                <React.Fragment key={terr}>
                  <tr className="bg-gray-100 font-bold text-brand-primary border-y border-gray-200">
                    <td colSpan={10} className="px-4 py-2">{terr}</td>
                  </tr>
                  {groupedData[terr].map(emp => {
                    const s = stats[emp.МП] || { avg: 0, total: 0, dist: {}, newDocsCount: 0, allVisits: [], newDocsVisits: [] };
                    return (
                      <tr key={emp.МП} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                        <td className="px-4 py-3 font-medium">{emp.МП}</td>
                        <td className="px-4 py-3 text-gray-500">{emp.Группа}</td>
                        <td className="px-4 py-3 text-right font-bold text-brand-accent">{s.avg}</td>
                        <td 
                          className={`px-4 py-3 text-right font-bold transition-colors ${s.total > 0 ? 'cursor-pointer hover:text-brand-accent' : ''}`}
                          onClick={() => handleCellClick(emp.МП, 'total', s.allVisits)}
                        >
                          {s.total}
                        </td>
                        {[ '1', '2', '3', '4', '5+' ].map(countKey => {
                          const docVisits = s.dist[countKey] || [];
                          const uniqueDocCount = new Set(docVisits.map(v => getVisitDoctor(v))).size;
                          return (
                            <td 
                              key={countKey}
                              className={`px-3 py-3 text-center transition-colors ${countKey === '1' ? 'border-l border-gray-100' : ''} ${uniqueDocCount > 0 ? 'cursor-pointer hover:bg-gray-100 font-medium' : 'text-gray-300'}`}
                              onClick={() => handleCellClick(emp.МП, countKey, docVisits)}
                            >
                              {uniqueDocCount}
                            </td>
                          );
                        })}
                        <td 
                          className={`px-4 py-3 text-right font-bold text-brand-accent bg-brand-accent/5 transition-colors ${s.newDocsCount > 0 ? 'cursor-pointer hover:bg-brand-accent/10' : ''}`}
                          onClick={() => handleCellClick(emp.МП, 'new', s.newDocsVisits)}
                        >
                          {s.newDocsCount}
                        </td>
                      </tr>
                    );
                  })}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modalInfo && (
        <DetailModal 
          title={modalInfo.title}
          subtitle={modalInfo.subtitle}
          items={modalInfo.items}
          onClose={() => setModalInfo(null)}
        />
      )}
    </div>
  );
};

export default AnalyticsSection;
