
import React, { useState, useMemo } from 'react';
import { GlobalState, Visit, Employee } from '../types';
// Added missing getVisitLPUFull to imports
import { normalizeDate, sortEmployees, getVisitRepName, getVisitLPUAbbr, getVisitDoctor, getVisitSpec, getVisitLPUFull } from '../utils';

interface Props {
  data: GlobalState;
}

const VisitsSection: React.FC<Props> = ({ data }) => {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedTerr, setSelectedTerr] = useState('');
  const [selectedRep, setSelectedRep] = useState('');
  const [selectedRole, setSelectedRole] = useState('МП');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [expandedRep, setExpandedRep] = useState<string | null>(null);

  const territories = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Область))).sort(), [data.allEmployees]);
  const reps = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.МП))).sort(), [data.allEmployees]);
  const roles = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Роль))).sort(), [data.allEmployees]);
  const statuses = useMemo(() => Array.from(new Set(data.allEmployees.map(e => e.Статус))).sort(), [data.allEmployees]);

  const tableData = useMemo(() => {
    const filteredEmployees = data.allEmployees.filter(emp => {
      if (selectedTerr && emp.Область !== selectedTerr) return false;
      if (selectedRep && emp.МП !== selectedRep) return false;
      if (selectedRole && emp.Роль !== selectedRole) return false;
      if (selectedStatus && emp.Статус !== selectedStatus) return false;
      return true;
    }).sort(sortEmployees);

    const grouped: Record<string, Employee[]> = {};
    filteredEmployees.forEach(emp => {
      if (!grouped[emp.Область]) grouped[emp.Область] = [];
      grouped[emp.Область].push(emp);
    });

    return grouped;
  }, [data.allEmployees, selectedTerr, selectedRep, selectedRole, selectedStatus]);

  const getRepVisits = (repName: string) => {
    return data.visits.filter(v => {
      const vDate = normalizeDate(getVisitDate(v));
      return vDate === date && getVisitRepName(v) === repName;
    });
  };

  const getVisitDate = (v: Visit) => v.Дата || v["Дата визита"] || '';

  const getRepReason = (repName: string) => {
    const fix = data.fixation.find(f => {
      const fDate = normalizeDate(f.Дата);
      return fDate === date && f.МП === repName;
    });
    return fix ? (fix.Причина || fix.Причины) : null;
  };

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Дата</label>
          <input type="date" value={date} onChange={e => setDate(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-brand-accent/20 outline-none" />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Территория</label>
          <select value={selectedTerr} onChange={e => setSelectedTerr(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {territories.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">МП</label>
          <select value={selectedRep} onChange={e => setSelectedRep(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {reps.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Роль</label>
          <select value={selectedRole} onChange={e => setSelectedRole(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {roles.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Статус</label>
          <select value={selectedStatus} onChange={e => setSelectedStatus(e.target.value)} className="text-sm border border-gray-300 rounded-lg px-3 py-2 outline-none">
            <option value="">Все</option>
            {statuses.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm border-collapse">
            <thead className="bg-brand-primary text-white text-xs uppercase font-bold text-left">
              <tr>
                <th className="px-4 py-3">Представитель</th>
                <th className="px-4 py-3">Группа</th>
                <th className="px-4 py-3 text-right">ЛПУ</th>
                <th className="px-4 py-3 text-right">Врачи</th>
                <th className="px-4 py-3 text-center">Статус</th>
                <th className="px-4 py-3">Причины</th>
              </tr>
            </thead>
            <tbody>
              {Object.keys(tableData).sort().map(terr => (
                <React.Fragment key={terr}>
                  <tr className="bg-gray-100 font-bold text-brand-primary border-y border-gray-200">
                    <td colSpan={6} className="px-4 py-2">{terr}</td>
                  </tr>
                  {tableData[terr].map(emp => {
                    const visits = getRepVisits(emp.МП);
                    const reason = getRepReason(emp.МП);
                    const hasVisits = visits.length > 0;
                    const lpuCount = new Set(visits.map(v => getVisitLPUAbbr(v))).size;
                    const docCount = new Set(visits.map(v => getVisitDoctor(v))).size;
                    const isExpanded = expandedRep === emp.МП;

                    return (
                      <React.Fragment key={emp.МП}>
                        <tr 
                          onClick={() => hasVisits && setExpandedRep(isExpanded ? null : emp.МП)}
                          className={`border-b border-gray-100 transition-colors cursor-pointer ${
                            !hasVisits ? (reason ? 'bg-amber-50' : 'bg-red-50') : 'hover:bg-gray-50'
                          }`}
                        >
                          <td className="px-4 py-3 font-medium flex items-center gap-2">
                            {hasVisits && (
                              <span className={`transform transition-transform ${isExpanded ? 'rotate-90' : ''}`}>▶</span>
                            )}
                            {emp.МП}
                          </td>
                          <td className="px-4 py-3 text-gray-500">{emp.Группа}</td>
                          <td className="px-4 py-3 text-right font-semibold">{hasVisits ? lpuCount : 0}</td>
                          <td className="px-4 py-3 text-right font-semibold">{hasVisits ? docCount : 0}</td>
                          <td className="px-4 py-3 text-center">
                            {hasVisits ? (
                              <span className="text-green-600 font-bold">✓</span>
                            ) : (
                              <span className="text-brand-accent font-bold">❌</span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-xs text-brand-accent font-medium italic">
                            {reason || (hasVisits ? '' : '—')}
                          </td>
                        </tr>
                        {isExpanded && hasVisits && (
                          <tr>
                            <td colSpan={6} className="bg-gray-50 p-4">
                              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                                {visits.map((v, i) => (
                                  <div key={i} className="bg-white p-3 rounded-xl border border-gray-200 shadow-xs text-xs">
                                    <div className="font-bold text-brand-primary mb-1">{getVisitDoctor(v)}</div>
                                    <div className="text-gray-500">{getVisitSpec(v)}</div>
                                    <div className="text-brand-accent font-semibold mt-1">{getVisitLPUAbbr(v)}: {getVisitLPUFull(v)}</div>
                                  </div>
                                ))}
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </React.Fragment>
              ))}
              {Object.keys(tableData).length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center text-gray-400 italic">
                    Нет данных для отображения
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default VisitsSection;
